package ui;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** 商品资料及金额计算。 */
public record 商品(int 编号, String 名称, BigDecimal 单价) {
    public 商品 {
        if (编号 <= 0) {
            throw new IllegalArgumentException("商品编号必须大于0");
        }
        if (名称 == null || 名称.isBlank()) {
            throw new IllegalArgumentException("商品名称不能为空");
        }
        if (单价 == null || 单价.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("商品单价不能小于0");
        }

        名称 = 名称.trim();
        单价 = 单价.setScale(2, RoundingMode.HALF_UP);
    }

    public BigDecimal 计算小计(int 数量) {
        if (数量 <= 0) {
            throw new IllegalArgumentException("商品数量必须大于0");
        }
        return 单价.multiply(BigDecimal.valueOf(数量));
    }

    public static String 格式化金额(BigDecimal 金额) {
        return 金额.setScale(2, RoundingMode.HALF_UP).toPlainString();
    }
}
