package ui;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

/** 购物系统唯一的界面与程序入口。 */
public final class 购物系统 {
    private static final String 分隔线 = "****************************************";

    private final Scanner 输入;
    private final Map<Integer, 商品> 商品列表 = new LinkedHashMap<>();

    public 购物系统(Scanner 输入) {
        this.输入 = 输入;
        初始化商品();
    }

    public static void main(String[] args) {
        try (Scanner 输入 = new Scanner(System.in, StandardCharsets.UTF_8)) {
            new 购物系统(输入).启动();
        }
    }

    public void 启动() {
        boolean 继续运行 = true;
        while (继续运行) {
            显示登录界面();
            int 选择 = 读取选择(1, 2, false);
            if (选择 == 1) {
                显示购物系统界面();
            } else {
                继续运行 = false;
            }
        }
        System.out.println("感谢使用淘宝乐购管理系统，再见！");
    }

    private void 显示登录界面() {
        System.out.println();
        System.out.println("\t欢迎使用淘宝乐购管理系统");
        System.out.println(分隔线);
        System.out.println("\t\t1.登录系统");
        System.out.println("\t\t2.退出");
        System.out.println(分隔线);
        System.out.print("请选择数字（1-2）：");
    }

    private void 显示购物系统界面() {
        boolean 已登录 = true;
        while (已登录) {
            System.out.println();
            System.out.println("\t欢迎使用淘宝乐购管理系统");
            System.out.println(分隔线);
            System.out.println("\t\t1.会员信息管理");
            System.out.println("\t\t2.购物结算");
            System.out.println("\t\t3.真情回馈");
            System.out.println("\t\t4.注销");
            System.out.println(分隔线);
            System.out.print("请选择数字（1-4）：");

            switch (读取选择(1, 4, false)) {
                case 1 -> {
                }
                case 2 -> 正常购买商品();
                case 3 -> {
                }
                case 4 -> 已登录 = false;
                default -> throw new IllegalStateException("无法识别的菜单选项");
            }
        }
    }

    private void 正常购买商品() {
        System.out.println();
        System.out.println("\t淘宝乐购管理系统 > 购物结算");
        System.out.println(分隔线);
        for (商品 item : 商品列表.values()) {
            System.out.printf("%d.%s（¥%s）%n",
                    item.编号(), item.名称(), 商品.格式化金额(item.单价()));
        }
        System.out.println("0.完成选购并结算");
        System.out.println(分隔线);

        Map<商品, Integer> 购物车 = new LinkedHashMap<>();
        while (true) {
            System.out.print("请选择商品编号（0-4）：");
            int 商品编号 = 读取选择(1, 商品列表.size(), true);
            if (商品编号 == 0) {
                break;
            }

            int 数量 = 读取正整数("请输入购买数量：");
            购物车.merge(商品列表.get(商品编号), 数量, Integer::sum);
            System.out.println("已加入购物车。");
        }

        if (购物车.isEmpty()) {
            System.out.println("本次没有选择商品。");
            等待返回();
            return;
        }

        BigDecimal 总金额 = BigDecimal.ZERO;
        System.out.println("\n商品\t单价\t数量\t小计");
        System.out.println("----------------------------------------");
        for (Map.Entry<商品, Integer> entry : 购物车.entrySet()) {
            商品 item = entry.getKey();
            int 数量 = entry.getValue();
            BigDecimal 小计 = item.计算小计(数量);
            总金额 = 总金额.add(小计);

            System.out.printf("%s\t¥%s\t%d\t¥%s%n",
                    item.名称(),
                    商品.格式化金额(item.单价()),
                    数量,
                    商品.格式化金额(小计));
        }
        System.out.println("----------------------------------------");
        System.out.println("应付金额：¥" + 商品.格式化金额(总金额));
        System.out.println("也是直接买完了，这波牛逼666！");
        等待返回();
    }

    private int 读取选择(int 最小值, int 最大值, boolean 允许零) {
        while (true) {
            String 内容 = 输入.nextLine().trim();
            try {
                int 数字 = Integer.parseInt(内容);
                if ((允许零 && 数字 == 0) || (数字 >= 最小值 && 数字 <= 最大值)) {
                    return 数字;
                }
            } catch (NumberFormatException ignored) {
            }
            System.out.printf("输入无效，请输入%s%d-%d之间的数字：",
                    允许零 ? "0或" : "", 最小值, 最大值);
        }
    }

    private int 读取正整数(String 提示) {
        while (true) {
            System.out.print(提示);
            String 内容 = 输入.nextLine().trim();
            try {
                int 数字 = Integer.parseInt(内容);
                if (数字 > 0) {
                    return 数字;
                }
            } catch (NumberFormatException ignored) {
            }
            System.out.println("请输入大于0的整数。");
        }
    }

    private void 等待返回() {
        System.out.print("按回车键返回购物系统界面……");
        输入.nextLine();
    }

    private void 初始化商品() {
        商品列表.put(1, new 商品(1, "衬衫", new BigDecimal("200.00")));
        商品列表.put(2, new 商品(2, "运动鞋", new BigDecimal("200")));
        商品列表.put(3, new 商品(3, "书包", new BigDecimal("990")));
        商品列表.put(4, new 商品(4, "玩具", new BigDecimal("230")));
    }
}
